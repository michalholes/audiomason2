from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Paths:
    repo_root: Path
    patch_dir: Path
    logs_dir: Path
    workspaces_dir: Path
    successful_dir: Path
    unsuccessful_dir: Path
    lock_path: Path
    symlink_path: Path


def ensure_dirs(paths: Paths) -> None:
    for d in [
        paths.patch_dir,
        paths.logs_dir,
        paths.workspaces_dir,
        paths.successful_dir,
        paths.unsuccessful_dir,
    ]:
        d.mkdir(parents=True, exist_ok=True)


def default_paths(repo_root: Path, patch_dir: Path) -> Paths:
    logs_dir = patch_dir / "logs"
    workspaces_dir = patch_dir / "workspaces"
    successful_dir = patch_dir / "successful"
    unsuccessful_dir = patch_dir / "unsuccessful"
    lock_path = patch_dir / "am_patch.lock"
    symlink_path = patch_dir / "am_patch.log"
    return Paths(
        repo_root=repo_root,
        patch_dir=patch_dir,
        logs_dir=logs_dir,
        workspaces_dir=workspaces_dir,
        successful_dir=successful_dir,
        unsuccessful_dir=unsuccessful_dir,
        lock_path=lock_path,
        symlink_path=symlink_path,
    )
