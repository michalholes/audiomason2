RUNNER_VERSION = "4.1.61"


def get_version() -> str:
    return RUNNER_VERSION
