"""Configurable Workflow Reader - loads and executes YAML workflows."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


class WorkflowStep:
    """Single workflow step definition."""

    def __init__(self, data: dict):
        self.id = data["id"]
        self.enabled = data.get("enabled", True)
        self.description = data.get("description", "")

        # Step type specific
        self.type = data.get("type")  # For preflight: menu, yes_no, input
        self.plugin = data.get("plugin")  # For processing: plugin name
        self.method = data.get("method")  # For processing: plugin method

        # Prompts
        self.prompt = data.get("prompt", "")
        self.default = data.get("default")
        self.required = data.get("required", False)

        # Hints
        self.hint_from = data.get("hint_from")
        self.hint_pattern = data.get("hint_pattern")

        # Conditions
        self.condition = data.get("condition")
        self.skip_if_set = data.get("skip_if_set", False)


class WorkflowConfig:
    """Workflow configuration from YAML."""

    def __init__(self, yaml_path: Path):
        """Load workflow from YAML file.

        Args:
            yaml_path: Path to workflow YAML
        """
        self.yaml_path = yaml_path
        self.data = self._load_yaml()

        # Parse workflow info
        workflow = self.data.get("workflow", {})
        self.name = workflow.get("name", "Unnamed Workflow")
        self.description = workflow.get("description", "")

        # Parse steps
        self.preflight_steps = [WorkflowStep(step) for step in workflow.get("preflight_steps", [])]

        self.processing_steps = [
            WorkflowStep(step) for step in workflow.get("processing_steps", [])
        ]

        # Verbosity settings
        self.verbosity_config = self.data.get("verbosity", {})

    def _load_yaml(self) -> dict:
        """Load YAML file.

        Returns:
            Parsed YAML data
        """
        if not self.yaml_path.exists():
            raise FileNotFoundError(f"Workflow file not found: {self.yaml_path}")

        with open(self.yaml_path) as f:
            return yaml.safe_load(f)

    def get_enabled_preflight_steps(self) -> list[WorkflowStep]:
        """Get list of enabled preflight steps.

        Returns:
            List of enabled steps
        """
        return [step for step in self.preflight_steps if step.enabled]

    def get_enabled_processing_steps(self) -> list[WorkflowStep]:
        """Get list of enabled processing steps.

        Returns:
            List of enabled steps
        """
        return [step for step in self.processing_steps if step.enabled]

    def extract_hint(self, step: WorkflowStep, source_value: str) -> str | None:
        """Extract hint from source value using regex pattern.

        Supports:
        - autor/kniha structure (source_value contains /)
        - Author - Title structure
        - Generic patterns

        Args:
            step: Workflow step with hint configuration
            source_value: Value to extract hint from

        Returns:
            Extracted hint or None
        """
        if not step.hint_pattern:
            return source_value

        # Special handling for autor/kniha structure
        if "/" in source_value:
            parts = source_value.split("/")

            # For author step - use first part (autor)
            if "author" in step.id.lower():
                return parts[0].strip()

            # For title step - use second part (kniha)
            if "title" in step.id.lower():
                # Clean up title (remove year, language codes)
                import re

                title = parts[1].strip()
                title = re.sub(r"\s*\(\d{4}\)\s*(\([A-Z]{2}\))?$", "", title)
                return title

        # Standard regex extraction
        try:
            match = re.search(step.hint_pattern, source_value)
            if match:
                extracted = match.group(1).strip()

                # Clean up if title
                if "title" in step.id.lower():
                    extracted = re.sub(r"\s*\(\d{4}\)\s*(\([A-Z]{2}\))?$", "", extracted)

                return extracted
        except Exception:
            pass

        return source_value

    def evaluate_condition(self, condition: str | None, context: dict) -> bool:
        """Evaluate step condition.

        Args:
            condition: Condition string (e.g. "answers.publish == true")
            context: Context dict with 'answers', 'config', etc.

        Returns:
            True if condition met or no condition
        """
        if not condition:
            return True

        # Simple evaluation - supports:
        # - answers.key == value
        # - config.key == value
        # - answers.key != value

        try:
            # Parse condition
            if " == " in condition:
                left, right_str = condition.split(" == ", 1)
                left = left.strip()
                right_str = right_str.strip().strip("\"'")

                # Evaluate left side
                value = self._get_nested_value(left, context)

                # Convert right side
                right_value: str | bool = right_str
                if right_str.lower() == "true":
                    right_value = True
                elif right_str.lower() == "false":
                    right_value = False

                return value == right_value

            elif " != " in condition:
                left, right2 = condition.split(" != ", 1)
                left = left.strip()
                right2 = right2.strip().strip("\"'")

                value = self._get_nested_value(left, context)

                # Convert right side
                right_value2: str | bool = right2
                if right2.lower() == "true":
                    right_value2 = True
                elif right2.lower() == "false":
                    right_value2 = False

                return value != right_value2

        except Exception:
            return True

        return True

    def _get_nested_value(self, path: str, context: dict) -> Any:
        """Get nested value from context.

        Args:
            path: Dot-separated path (e.g. "answers.publish")
            context: Context dictionary

        Returns:
            Value at path or None
        """
        parts = path.split(".")
        current: Any = context

        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None

        return current

    def should_show_messages(self, verbosity: int, message_type: str) -> bool:
        """Check if message type should be shown at verbosity level.

        Args:
            verbosity: Verbosity level (0-3)
            message_type: Type of message (e.g. 'errors', 'prompts')

        Returns:
            True if should show
        """
        level_names = ["quiet", "normal", "verbose", "debug"]

        if verbosity < 0 or verbosity >= len(level_names):
            return False

        level_name = level_names[verbosity]
        allowed_types = self.verbosity_config.get(level_name, [])

        return message_type in allowed_types
