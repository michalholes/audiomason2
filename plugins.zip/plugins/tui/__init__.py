"""TUI plugin package."""
